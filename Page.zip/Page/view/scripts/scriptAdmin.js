// supprime la ligne du tableau identifié par son numéro de ligne numLigne
function SupprLigne(numLigne){
  document.getElementById("tableau").deleteRow(i);
}
